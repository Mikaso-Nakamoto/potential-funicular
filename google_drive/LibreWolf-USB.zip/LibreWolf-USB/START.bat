@echo off
chcp 65001 >nul
title LibreWolf-USB
echo.
echo   ============================================================
echo    LibreWolf-USB  |  весь трафик через VPN (kill-switch активен)
echo   ============================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\start.ps1"
set EC=%ERRORLEVEL%
echo.
if "%EC%"=="2" (
  echo   [!] Сессия прервана KILL-SWITCH — браузер остановлен принудительно.
) else if not "%EC%"=="0" (
  echo   [!] Ошибка запуска, код %EC% — смотри сообщение выше.
)
echo   Нажми любую клавишу, чтобы закрыть окно...
pause >nul
exit /b %EC%
