﻿# vless-lib.ps1 — общая библиотека: разбор vless:// ссылок и сборка конфига Xray
# (мульти-серверного: балансировщик leastPing + observatory, как в методичке).
# Подключается точкой (dot-source) из vless-to-config.ps1 и update-sub.ps1.

function JsonEsc([string]$v) {
    if ($null -eq $v) { return '' }
    return $v.Replace('\', '\\').Replace('"', '\"')
}

function ConvertFrom-VlessLink([string]$Link) {
    # Возвращает [pscustomobject] с полями узла или $null (с предупреждением).
    $link = "$Link".Trim()
    if ($link -notlike 'vless://*') { Write-Warning "не vless:// ссылка — пропускаю"; return $null }
    $link = $link.Substring(8)

    $name = ''
    $pos = $link.IndexOf('#')
    if ($pos -ge 0) {
        $name = [Uri]::UnescapeDataString($link.Substring($pos + 1))
        $link = $link.Substring(0, $pos)
    }
    $query = @{}
    $pos = $link.IndexOf('?')
    if ($pos -ge 0) {
        $qs = $link.Substring($pos + 1)
        $link = $link.Substring(0, $pos)
        foreach ($pair in ($qs -split '&')) {
            if ([string]::IsNullOrEmpty($pair)) { continue }
            $k = $pair; $v = ''
            $eq = $pair.IndexOf('=')
            if ($eq -ge 0) { $k = $pair.Substring(0, $eq); $v = $pair.Substring($eq + 1) }
            $query[$k.ToLower()] = [Uri]::UnescapeDataString($v)
        }
    }
    $link = $link.Trim('/')
    if ($link -notmatch '^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})@(\[[^\]]+\]|[^:@/]+):(\d+)$') {
        Write-Warning "не удалось разобрать uuid@адрес:порт — пропускаю"
        return $null
    }
    $uuid = $Matches[1]
    $addr = $Matches[2]
    if ($addr.StartsWith('[')) { $addr = $addr.Substring(1, $addr.Length - 2) }
    $port = [int]$Matches[3]

    function Q([string]$k) {
        $k = $k.ToLower()
        if ($query.ContainsKey($k)) { return "$($query[$k])" }
        return ''
    }
    $net = Q 'type';       if (-not $net) { $net = 'tcp' }
    $sec = Q 'security';   if (-not $sec) { $sec = 'none' }

    $node = [pscustomobject]@{
        uuid = $uuid; address = $addr; port = $port; name = $name
        net = $net; sec = $sec
        flow = (Q 'flow');   sni = (Q 'sni');        fp = (Q 'fp')
        host = (Q 'host');   path = (Q 'path');      serviceName = (Q 'servicename')
        alpn = (Q 'alpn');   pbk = (Q 'pbk');        sid = (Q 'sid')
        spx = (Q 'spx');     headerType = (Q 'headertype')
    }
    # валидация: REALITY без ключа/SNI неработоспособна
    if ($sec -eq 'reality') {
        if (-not $node.pbk) { Write-Warning "REALITY без publicKey (pbk) — пропускаю: $addr"; return $null }
        if (-not $node.sni) { Write-Warning "REALITY без serverName (sni) — пропускаю: $addr"; return $null }
    }
    return $node
}

function New-StreamSettingsJson($Node) {
    # многострочный блок streamSettings с отступом 6 (без обёртки)
    $M = New-Object System.Collections.Generic.List[string]
    $M.Add('      "network": "' + (JsonEsc $Node.net) + '"')
    $M.Add('      "security": "' + (JsonEsc $Node.sec) + '"')

    switch ($Node.net) {
        'ws' {
            $p = $Node.path; if (-not $p) { $p = '/' }
            $b = '      "wsSettings": {' + "`n" + '        "path": "' + (JsonEsc $p) + '"'
            if ($Node.host) { $b += ",`n" + '        "headers": { "Host": "' + (JsonEsc $Node.host) + '" }' }
            $b += "`n" + '      }'
            $M.Add($b)
        }
        'grpc' {
            $M.Add('      "grpcSettings": {' + "`n" + '        "serviceName": "' + (JsonEsc $Node.serviceName) + '"' + "`n" + '      }')
        }
        'httpupgrade' {
            $p = $Node.path; if (-not $p) { $p = '/' }
            $b = '      "httpupgradeSettings": {' + "`n" + '        "path": "' + (JsonEsc $p) + '"'
            if ($Node.host) { $b += ",`n" + '        "host": "' + (JsonEsc $Node.host) + '"' }
            $b += "`n" + '      }'
            $M.Add($b)
        }
        'tcp' {
            if ($Node.headerType -eq 'http') {
                $p = $Node.path; if (-not $p) { $p = '/' }
                $M.Add('      "tcpSettings": {' + "`n" + '        "header": { "type": "http", "request": { "path": ["' + (JsonEsc $p) + '"], "headers": { "Host": ["' + (JsonEsc $Node.host) + '"] } } }' + "`n" + '      }')
            }
        }
    }

    if ($Node.sec -eq 'tls') {
        $sn = $Node.sni; if (-not $sn) { $sn = $Node.host }; if (-not $sn) { $sn = $Node.address }
        $fp = $Node.fp; if (-not $fp) { $fp = 'chrome' }
        $b = '      "tlsSettings": {' + "`n" + '        "serverName": "' + (JsonEsc $sn) + '",' + "`n" + '        "fingerprint": "' + (JsonEsc $fp) + '"'
        if ($Node.alpn) { $b += ",`n" + '        "alpn": ["' + ($Node.alpn -replace ',', '","') + '"]' }
        $b += "`n" + '      }'
        $M.Add($b)
    }
    elseif ($Node.sec -eq 'reality') {
        $fp = $Node.fp; if (-not $fp) { $fp = 'firefox' }
        $b = '      "realitySettings": {' + "`n" +
             '        "show": false,' + "`n" +
             '        "fingerprint": "' + (JsonEsc $fp) + '",' + "`n" +
             '        "serverName": "' + (JsonEsc $Node.sni) + '",' + "`n" +
             '        "publicKey": "' + (JsonEsc $Node.pbk) + '"'
        if ($Node.sid) { $b += ",`n" + '        "shortId": "' + (JsonEsc $Node.sid) + '"' }
        if ($Node.spx) { $b += ",`n" + '        "spiderX": "' + (JsonEsc $Node.spx) + '"' }
        $b += "`n" + '      }'
        $M.Add($b)
    }
    return ($M -join ",`n")
}

function New-OutboundJson($Node, [int]$Index) {
    # полный блок одного outbound, отступ членов 4
    $u = '              { "id": "' + $Node.uuid + '", "encryption": "none"'
    if ($Node.flow -and ($Node.sec -eq 'reality' -or $Node.sec -eq 'tls')) {
        $u += ', "flow": "' + (JsonEsc $Node.flow) + '"'
    }
    $u += ' }'

    $M = New-Object System.Collections.Generic.List[string]
    $M.Add('    "tag": "proxy-' + $Index + '"')
    $M.Add('    "protocol": "vless"')
    $M.Add('    "settings": {' + "`n" +
           '      "vnext": [' + "`n" +
           '        {' + "`n" +
           '          "address": "' + (JsonEsc $Node.address) + '",' + "`n" +
           '          "port": ' + $Node.port + ',' + "`n" +
           '          "users": [' + "`n" + $u + "`n" +
           '          ]' + "`n" +
           '        }' + "`n" +
           '      ]' + "`n" +
           '    }')
    $M.Add('    "streamSettings": {' + "`n" + (New-StreamSettingsJson $Node) + "`n" + '    }')
    return ($M -join ",`n")
}

function New-ConfigJson($Nodes) {
    # полный конфиг: SOCKS 10808 + HTTP 10809, N прокси, freedom, blackhole,
    # observatory и routing c балансировщиком leastPing (весь трафик — только через прокси)
    $ob = New-Object System.Collections.Generic.List[string]
    $i = 0
    foreach ($n in $Nodes) { $i++; $ob.Add('    {' + "`n" + (New-OutboundJson $n $i) + "`n" + '    }') }
    $ob.Add('    { "protocol": "freedom", "tag": "direct" }')
    $ob.Add('    { "protocol": "blackhole", "tag": "block" }')
    $outbounds = ($ob -join ",`n")
    return @"
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "port": 10808,
      "protocol": "socks",
      "settings": { "auth": "noauth", "udp": true },
      "sniffing": { "enabled": true, "destOverride": ["http", "tls"] }
    },
    {
      "tag": "http-in",
      "listen": "127.0.0.1",
      "port": 10809,
      "protocol": "http",
      "settings": {}
    }
  ],
  "outbounds": [
$outbounds
  ],
  "observatory": {
    "subjectSelector": ["proxy-"],
    "probeURL": "https://www.gstatic.com/generate_204",
    "probeInterval": "3m",
    "enableConcurrency": true
  },
  "routing": {
    "domainStrategy": "AsIs",
    "balancers": [
      {
        "tag": "all-proxies",
        "selector": ["proxy-"],
        "strategy": { "type": "leastPing" }
      }
    ],
    "rules": [
      { "type": "field", "network": "tcp,udp", "balancerTag": "all-proxies" }
    ]
  }
}
"@
}

# ---------- работа с подпиской (общее для update-sub.ps1 и start.ps1) ----------

function Read-SubParams([string]$SubFile) {
    # читает vpn\sub.txt -> @{url;hwid;ua}; $null, если файла нет или url пуст
    if (-not (Test-Path $SubFile)) { return $null }
    $p = @{ url = ''; hwid = ''; ua = 'INCY/3.0.28' }
    foreach ($ln in [IO.File]::ReadAllLines($SubFile)) {
        if ($ln -match '^\s*(\w+)\s*=\s*(.*)$') {
            switch ($Matches[1].ToLower()) {
                'url'  { $p.url  = $Matches[2].Trim() }
                'hwid' { $p.hwid = $Matches[2].Trim() }
                'ua'   { $p.ua   = $Matches[2].Trim() }
            }
        }
    }
    if (-not $p.url) { return $null }
    return $p
}

function Get-SubBody([string]$Url, [string]$Hwid, [string]$Ua, [int]$ProxyPort = 0) {
    # скачивает тело подписки (через локальный SOCKS, если ProxyPort > 0),
    # распаковывает base64 (в т.ч. без паддинга и url-safe). '' = не получилось.
    $a = @('-s', '-L', '--fail', '--max-time', '20', '-H', "User-Agent: $Ua")
    if ($Hwid)  { $a += @('-H', "x-hwid: $Hwid") }
    if ($ProxyPort -gt 0) { $a += @('--socks5-hostname', "127.0.0.1:$ProxyPort") }
    $body = (& curl.exe @a $Url) -join "`n"
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($body)) { return '' }
    $text = $body.Trim()
    if ($text -notlike '*vless://*') {
        $b = ($text -replace '\s', '').Replace('-', '+').Replace('_', '/')
        $b += '=' * ((4 - ($b.Length % 4)) % 4)
        try { $text = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b)) }
        catch { return '' }
    }
    return $text
}

function ConvertTo-Nodes([string]$Text) {
    # текст подписки -> массив узлов (валидные vless://, без дублей)
    $nodes = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    foreach ($ln in ($Text -split "`n")) {
        $ln = "$ln".Trim()
        if (-not $ln -or $ln -notlike 'vless://*') { continue }
        $n = ConvertFrom-VlessLink $ln
        if (-not $n) { continue }
        $key = "$($n.uuid)|$($n.address)|$($n.port)"
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true
        $nodes.Add($n)
    }
    return @($nodes)
}
