// LibreWolf-USB — профиль браузера работает ТОЛЬКО через локальный SOCKS-прокси Xray.
// Этот файл копируется в profile\ при каждом запуске START.bat; вручную не править.

// --- прокси: без него браузер в интернет не ходит вообще ---
user_pref("network.proxy.type", 1);                  // ручной прокси (0=никак, 5=системный — запрещаем)
user_pref("network.proxy.socks", "127.0.0.1");
user_pref("network.proxy.socks_port", 10808);
user_pref("network.proxy.socks_version", 5);
user_pref("network.proxy.socks_remote_dns", true);   // DNS тоже через прокси (утечки DNS нет)

// --- прочие утечки и следы ---
user_pref("media.peerconnection.enabled", false);    // WebRTC выкл (не светит IP)
user_pref("network.captive-portal-service.enabled", false);
user_pref("network.connectivity-service.enabled", false);
user_pref("browser.cache.disk.enable", false);       // кэш только в ОЗУ, не на диске ПК
user_pref("browser.cache.memory.enable", true);
user_pref("browser.sessionstore.resume_from_crash", false);
user_pref("browser.startup.page", 0);                // не восстанавливать сессию
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.pagethumbnails.capturing_disabled", true);
user_pref("app.update.enabled", false);
user_pref("extensions.update.enabled", false);
user_pref("network.prefetch-next", false);
user_pref("network.dns.disablePrefetch", true);

// --- «грязные ПК»: НИКАКИХ реальных аккаунтов и синхронизации ---
user_pref("identity.fxaccounts.enabled", false);     // аккаунты Firefox выключены
user_pref("signon.rememberSignons", false);          // НЕ сохранять пароли (кража профиля = кража паролей)
user_pref("browser.formfill.enable", false);         // не запоминать данные форм
user_pref("extensions.webservice.discoverURL", "");
