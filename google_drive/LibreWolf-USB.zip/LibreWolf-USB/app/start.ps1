﻿# start.ps1 — LibreWolf-USB: запуск браузера ТОЛЬКО через Xray (VLESS)
# с kill-switch и авто-обновлением подписки ЧЕРЕЗ туннель (если конфиг устарел).
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'vless-lib.ps1')

# --- пути и настройки ---
$App     = $PSScriptRoot
$Root    = Split-Path -Parent $App
$Vpn     = Join-Path $Root 'vpn'
$Logs    = Join-Path $Vpn 'logs'
$Profile = Join-Path $Root 'profile'
$Cfg     = Join-Path $Vpn 'config.json'
$SubFile = Join-Path $Vpn 'sub.txt'
$Xray    = Join-Path $Vpn 'xray.exe'
$Port    = 10808
$Ts      = Get-Date -Format 'yyyyMMdd-HHmmss'
$LogFile = Join-Path $Logs "session-$Ts.log"
$SubMaxAgeDays = 3   # старше — пробуем обновить подписку через туннель
$script:XraySeq = 0

function Log([string]$msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    Write-Host $line
    try { Add-Content -Path $LogFile -Value $line -Encoding UTF8 } catch {}
}

function Fail([string]$msg, [int]$code = 1) {
    Write-Host ""
    Write-Host "[X] $msg" -ForegroundColor Red
    try { Add-Content -Path $LogFile -Value "[XX] $msg" -Encoding UTF8 } catch {}
    exit $code
}

# --- внешний IP (через прокси, если указан; иначе прямой) ---
function Get-ExtIP([int]$ProxyPort = 0) {
    foreach ($u in @('https://api.ipify.org', 'https://ifconfig.me/ip')) {
        try {
            $curlArgs = @('-s', '--max-time', '12')
            if ($ProxyPort -gt 0) { $curlArgs += @('--socks5-hostname', "127.0.0.1:$ProxyPort") }
            $r = & curl.exe @curlArgs $u 2>$null
            $r = "$r".Trim()
            if ($r -match '^[0-9a-fA-F.:\[\]]+$' -and $r.Length -le 45) { return $r }
        } catch {}
    }
    return ''
}

function Test-Socks([int]$P) {
    $c = New-Object Net.Sockets.TcpClient
    try {
        $t = $c.ConnectAsync('127.0.0.1', $P)
        if ($t.Wait(1500) -and $c.Connected) { return $true }
    } catch {}
    finally { $c.Dispose() }
    return $false
}

function Start-XrayProc {
    # запуск xray со текущим config.json (конфиг читает сам xray, нигде не открывается)
    $script:XraySeq++
    $OutLog = Join-Path $Logs ("xray-out-$Ts-$($script:XraySeq).log")
    $ErrLog = Join-Path $Logs ("xray-err-$Ts-$($script:XraySeq).log")
    Log "запуск xray (попытка $($script:XraySeq))"
    return (Start-Process -FilePath $Xray -ArgumentList @('-c', "`"$Cfg`"") `
        -WorkingDirectory $Vpn -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $OutLog -RedirectStandardError $ErrLog)
}

function Wait-SocksReady($Proc) {
    for ($i = 0; $i -lt 30; $i++) {
        if ($Proc.HasExited) { return $false }
        if (Test-Socks $Port) { return $true }
        Start-Sleep -Milliseconds 1000
    }
    return $false
}

# --- баннер ---
Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "  LibreWolf-USB  |  VPN-only browser session"       -ForegroundColor Cyan
Write-Host "  весь трафик -> Xray (VLESS) -> SOCKS 127.0.0.1:$Port" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $Logs | Out-Null
Log "=== старт сессии $Ts ==="

# --- проверки ---
if (-not (Test-Path $Cfg)) {
    Fail "Нет vpn\config.json. Дома запусти ПОДГОТОВКА-ДОМА.bat и конвертер VLESS-ссылок (см. README)."
}
if (-not (Test-Path $Xray)) {
    Fail "Нет vpn\xray.exe. Дома запусти ПОДГОТОВКА-ДОМА.bat (скачает Xray и LibreWolf)."
}
try { $null = (Get-Content $Cfg -Raw -Encoding UTF8 | ConvertFrom-Json) }
catch { Fail "vpn\config.json повреждён. Дома пересоздай его конвертером (ПОДГОТОВКА-ДОМА.bat)." }
$cfgAge = ((Get-Date) - (Get-Item $Cfg).LastWriteTime).TotalDays

$Exe = $null
foreach ($dir in @((Join-Path $App 'LibreWolf'), $App, $Root)) {
    if (Test-Path $dir) {
        $Exe = Get-ChildItem -Path $dir -Recurse -Filter 'LibreWolf.exe' -ErrorAction SilentlyContinue |
               Select-Object -First 1 -ExpandProperty FullName
        if (-not $Exe) {
            $Exe = Get-ChildItem -Path $dir -Recurse -Filter 'LibreWolf-Portable.exe' -ErrorAction SilentlyContinue |
                   Select-Object -First 1 -ExpandProperty FullName
        }
        if ($Exe) { break }
    }
}
if (-not $Exe) { Fail "LibreWolf.exe не найден. Дома запусти ПОДГОТОВКА-ДОМА.bat (скачает браузер)." }
Log "браузер: $Exe"

# --- профиль на флешке + жёсткая привязка к прокси (user.js перезаписывается каждый запуск) ---
New-Item -ItemType Directory -Force -Path $Profile | Out-Null
Copy-Item (Join-Path $App 'user.js') (Join-Path $Profile 'user.js') -Force
Remove-Item (Join-Path $Profile 'parent.lock'), (Join-Path $Profile '.parentlock') -ErrorAction SilentlyContinue
Log "профиль: $Profile (на флешке, не на диске ПК)"

# --- реальный IP ДО старта VPN (один запрос curl, в браузер не идёт, на диск не пишется) ---
Write-Host "[..] Определяю прямой IP (для контроля утечки)..." -ForegroundColor DarkGray
$RealIP = Get-ExtIP
if ($RealIP) { Log "прямой IP: $RealIP (только в памяти)" }
else { Write-Host "[i] Прямой IP определить не удалось — проверка на утечку будет по ответу прокси" -ForegroundColor Yellow }

# --- запуск xray на ТЕКУЩЕМ (старом) конфиге ---
$XrayProc = Start-XrayProc
if (-not (Wait-SocksReady $XrayProc)) {
    if (-not $XrayProc.HasExited) { Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue }
    Fail "Xray не поднял SOCKS на 127.0.0.1:$Port. Подробности: vpn\logs\xray-err-$Ts-*.log (смотреть ДОМА)."
}
Log "SOCKS 127.0.0.1:$Port поднялся"

$VpnIP = Get-ExtIP $Port
if (-not $VpnIP) {
    Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
    Fail "Через VPN не удалось определить внешний IP (сервер недоступен/блокируется). Браузер НЕ запущен. Лог: vpn\logs\ (смотреть дома)."
}
if ($RealIP -and ($VpnIP -eq $RealIP)) {
    Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
    Fail "УТЕЧКА ещё до старта: через прокси виден реальный IP ($VpnIP). Браузер НЕ запущен."
}
Log "внешний IP через VPN: $VpnIP"
Write-Host "[OK] Внешний IP через VPN: $VpnIP" -ForegroundColor Green
if ($RealIP) { Write-Host "     (прямой $RealIP — отличается)" -ForegroundColor DarkGray }

# --- АВТООБНОВЛЕНИЕ ПОДПИСКИ ЧЕРЕЗ ТУННЕЛЬ ---
# Старый ключ поднял VPN -> запрос к API идёт ЧЕРЕЗ VPN (колледж видит только
# шифрованный туннель) -> новый конфиг -> перезапуск xray -> повторная проверка.
if ((Test-Path $SubFile) -and ($cfgAge -ge $SubMaxAgeDays)) {
    Write-Host "[..] Конфигу $([int]$cfgAge) дн. — обновляю подписку ЧЕРЕЗ VPN..." -ForegroundColor Yellow
    Log "авто-обновление подписки (конфигу $([int]$cfgAge) дн.)"
    try {
        $sp = Read-SubParams $SubFile
        $nodes = @()
        if ($sp -and $sp.url) {
            $text = Get-SubBody $sp.url $sp.hwid $sp.ua $Port
            if ($text) { $nodes = ConvertTo-Nodes $text }
        }
        if ($nodes.Count -gt 0) {
            Copy-Item $Cfg "$Cfg.bak.json" -Force
            [IO.File]::WriteAllText($Cfg, (New-ConfigJson $nodes), (New-Object System.Text.UTF8Encoding $false))
            Log "получено $($nodes.Count) сервер(ов) — перезапускаю xray с новым конфигом"
            Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
            $XrayProc = Start-XrayProc
            $okNew  = (Wait-SocksReady $XrayProc)
            $ipNew  = ''
            if ($okNew) { $ipNew = Get-ExtIP $Port }
            if ($okNew -and $ipNew -and -not ($RealIP -and ($ipNew -eq $RealIP))) {
                $VpnIP = $ipNew
                Log "обновление успешно: $ipNew"
                Write-Host "[OK] Конфиг обновлён ($($nodes.Count) серверов), IP через VPN: $ipNew" -ForegroundColor Green
            } else {
                Write-Host "[!] Новый конфиг не заработал — откатываю на прежний" -ForegroundColor Red
                Log "новый конфиг не прошёл проверку — откат на config.bak.json"
                Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
                Copy-Item "$Cfg.bak.json" $Cfg -Force
                $XrayProc = Start-XrayProc
                if (-not (Wait-SocksReady $XrayProc)) {
                    if (-not $XrayProc.HasExited) { Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue }
                    Fail "Ни новый, ни старый конфиг не поднялись. vpn\logs\ — смотреть дома."
                }
                $ipOld = Get-ExtIP $Port
                if (-not $ipOld -or ($RealIP -and ($ipOld -eq $RealIP))) {
                    Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
                    Fail "После отката VPN не отвечает. vpn\logs\ — смотреть дома."
                }
                $VpnIP = $ipOld
                Write-Host "[i] Работаю на прежнем конфиге (IP: $ipOld)" -ForegroundColor Yellow
            }
        } else {
            Write-Host "[i] Подписка недоступна/пуста — работаю на старом конфиге" -ForegroundColor Yellow
            Log "авто-обновление: подписка недоступна или без валидных узлов — продолжаю на старом конфиге"
        }
    } catch {
        Write-Host "[i] Авто-обновление не получилось ($($_.Exception.Message)) — работаю на старом конфиге" -ForegroundColor Yellow
        Log "авто-обновление: ошибка: $($_.Exception.Message)"
        if (-not (Get-Process -Id $XrayProc.Id -ErrorAction SilentlyContinue)) {
            # xray успел остановиться до ошибки — поднимаем заново на старом конфиге
            Copy-Item "$Cfg.bak.json" $Cfg -Force -ErrorAction SilentlyContinue
            $XrayProc = Start-XrayProc
            if (-not (Wait-SocksReady $XrayProc)) {
                if (-not $XrayProc.HasExited) { Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue }
                Fail "Xray не поднялся после сбоя обновления. vpn\logs\ — смотреть дома."
            }
            $ipR = Get-ExtIP $Port
            if (-not $ipR -or ($RealIP -and ($ipR -eq $RealIP))) {
                Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
                Fail "VPN не отвечает после сбоя обновления. vpn\logs\ — смотреть дома."
            }
            $VpnIP = $ipR
        }
    }
} elseif ($cfgAge -ge 7) {
    Write-Host "[i] Конфигу VPN уже $([int]$cfgAge) дн. — серверы могли смениться." -ForegroundColor Yellow
    Write-Host "    Дома обнови: powershell -ExecutionPolicy Bypass -File app\update-sub.ps1" -ForegroundColor Yellow
    Log "конфигу $([int]$cfgAge) дней (подписки/sub.txt на флешке нет — авто-обновление невозможно)"
}

# ============ KILL-SWITCH WATCHDOG (фоновый поток) ============
$s = [hashtable]::Synchronized(@{})
$s.stop      = $false
$s.breach    = $null
$s.realIP    = $RealIP
$s.xrayPid   = $XrayProc.Id
$s.xrayExe   = $Xray
$s.browserExe= $Exe
$s.port      = $Port
$s.lastIP    = $VpnIP
$s.events    = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))

$WatchdogSrc = @'
# $s — синхронизированная hashtable, передана через SessionStateProxy.SetVariable
function Get-IP([int]$P) {
    foreach ($u in @('https://api.ipify.org','https://ifconfig.me/ip')) {
        try {
            $r = & curl.exe -s --max-time 12 --socks5-hostname "127.0.0.1:$P" $u 2>$null
            $r = "$r".Trim()
            if ($r -match '^[0-9a-fA-F.:\[\]]+$' -and $r.Length -le 45) { return $r }
        } catch {}
    }
    return ''
}
function Breach([string]$why) {
    try {
        foreach ($n in @('librewolf','firefox')) {
            Get-Process -Name $n -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        }
        Get-Process -Name 'xray' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    } catch {}
    $admin = $false
    try {
        $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                 ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {}
    if ($admin) {
        try {
            New-NetFirewallRule -DisplayName 'LibreWolf-USB-KILLSWITCH' -Direction Outbound `
                -Program $s.browserExe -Action Block -ErrorAction SilentlyContinue | Out-Null
            New-NetFirewallRule -DisplayName 'LibreWolf-USB-KILLSWITCH-XRAY' -Direction Outbound `
                -Program $s.xrayExe -Action Block -ErrorAction SilentlyContinue | Out-Null
        } catch {}
    }
    $s.breach = $why
    [void]$s.events.Add("KILL-SWITCH: $why")
    try { [console]::beep(1400,250); [console]::beep(1400,250) } catch {}
    try {
        (New-Object -ComObject WScript.Shell).Popup(
            "KILL-SWITCH сработал`n`n$why`n`nБраузер и VPN остановлены.`nБрандмауэр: $admin",
            0, 'LibreWolf-USB: соединение разорвано', 16) | Out-Null
    } catch {}
}
$sockFail = 0
$ipFail   = 0
$i = 0
while (-not $s.stop) {
    Start-Sleep -Milliseconds 5000
    if ($s.stop) { break }
    $i++
    # 1) xray жив?
    if (-not (Get-Process -Id $s.xrayPid -ErrorAction SilentlyContinue)) {
        Breach "Xray прекратил работу (обход VPN стал возможен)"; break
    }
    # 2) SOCKS отвечает?
    $ok = $false
    try {
        $c = New-Object Net.Sockets.TcpClient
        $t = $c.ConnectAsync('127.0.0.1', $s.port)
        if ($t.Wait(1500) -and $c.Connected) { $ok = $true }
        $c.Dispose()
    } catch {}
    if (-not $ok) {
        $sockFail++
        if ($sockFail -ge 3) { Breach "SOCKS-прокси перестал отвечать"; break }
        continue
    }
    $sockFail = 0
    # 3) внешний IP через прокси — каждые ~30 сек
    if (($i % 6) -eq 0) {
        $ip = Get-IP $s.port
        if ([string]::IsNullOrWhiteSpace($ip)) {
            $ipFail++
            if ($ipFail -ge 3) { Breach "VPN перестал отвечать (IP через прокси не определяется)"; break }
        } else {
            $ipFail = 0
            $s.lastIP = $ip
            if ($s.realIP -and ($ip -eq $s.realIP)) {
                Breach "УТЕЧКА: через прокси виден реальный IP ($ip)"; break
            }
        }
    }
}
'@

$Rs = [runspacefactory]::CreateRunspace()
$Rs.ApartmentState = 'STA'
$Rs.Open()
$Rs.SessionStateProxy.SetVariable('s', $s)
$Ps = [powershell]::Create()
$Ps.Runspace = $Rs
[void]$Ps.AddScript($WatchdogSrc)
$Handle = $Ps.BeginInvoke()
Log "kill-switch активен (проверка каждые 5 сек, IP каждые ~30 сек)"

# --- запуск браузера ---
Log "запуск LibreWolf (профиль на флешке, прокси зашит в user.js)"
$Browser = Start-Process -FilePath $Exe -ArgumentList "-no-remote -profile `"$Profile`"" -PassThru
$s.browserPid = $Browser.Id

Write-Host ""
Write-Host "[>>] Браузер запущен. Закрой его сам, когда закончишь." -ForegroundColor Green
Write-Host "     kill-switch работает в этом окне — не закрывай его до конца сессии." -ForegroundColor Yellow
Write-Host ""

# --- ожидание завершения / срабатывания kill-switch ---
while ($true) {
    if ($s.breach) { break }
    if (-not (Get-Process -Id $Browser.Id -ErrorAction SilentlyContinue)) { break }
    while ($s.events.Count -gt 0) {
        $ev = $s.events[0]; $s.events.RemoveAt(0)
        Log $ev
    }
    Start-Sleep -Milliseconds 1000
}

# --- остановка watchdog ---
$s.stop = $true
Start-Sleep -Milliseconds 6500
if (-not $Ps.IsCompleted) { try { $Ps.Stop() } catch {} }
try { $Ps.Dispose(); $Rs.Close() } catch {}

# --- финал ---
if ($s.breach) {
    Log "сессия ПРЕРВАНА: $($s.breach)"
    Stop-Process -Name 'librewolf','firefox','xray' -Force -ErrorAction SilentlyContinue
    Write-Host ""
    Write-Host "[!!] Сессия прервана kill-switch'ем: $($s.breach)" -ForegroundColor Red
    Write-Host "     Если хочешь продолжить — проверь интернет/VPN и запусти START.bat заново." -ForegroundColor Yellow
    exit 2
}

Stop-Process -Id $XrayProc.Id -Force -ErrorAction SilentlyContinue
Get-Process -Name 'xray' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Log "браузер закрыт пользователем, xray остановлен, сессия чистая"
Write-Host ""
Write-Host "[OK] Браузер закрыт, VPN остановлен." -ForegroundColor Green
Write-Host "[i] Перед извлечением флешки запусти ЧИСТКА.bat (сотрёт следы на этом ПК)." -ForegroundColor Cyan
exit 0
