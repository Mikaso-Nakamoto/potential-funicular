﻿# prepare-home.ps1 — ДОМАШНЯЯ подготовка флешки LibreWolf-USB.
# Скачивает LibreWolf (portable) с GitLab и Xray-core с GitHub, проверяет sha256,
# раскладывает по папкам и (если нужно) конвертирует VLESS-ссылку в vpn\config.json.
# В колледже этот скрипт НЕ запускать (ссылка вставляется только дома).
$ErrorActionPreference = 'Stop'
$App  = $PSScriptRoot
$Root = Split-Path -Parent $App
$Vpn  = Join-Path $Root 'vpn'
$Dl   = Join-Path $Root '_download'

function Fail([string]$msg) {
    Write-Host ""
    Write-Host "[X] $msg" -ForegroundColor Red
    Write-Host "    Интернет должен быть обычным (домашним), без прокси-блокировок." -ForegroundColor DarkGray
    exit 1
}

function Download([string]$url, [string]$out) {
    Write-Host "     $url"
    & curl.exe -L --fail --retry 3 --connect-timeout 20 --progress-bar -o "$out" "$url"
    if ($LASTEXITCODE -ne 0) { Fail "Не скачалось: $url" }
    if (-not (Test-Path $out) -or (Get-Item $out).Length -lt 100000) { Fail "Файл пустой/битый: $out" }
}

Write-Host ""
Write-Host "=== LibreWolf-USB: подготовка ДОМА ===" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $Dl, $Vpn | Out-Null

# ---------- 1. LibreWolf ----------
Write-Host ""
Write-Host "[1/3] LibreWolf (portable) — узнаю последнюю версию с GitLab..." -ForegroundColor Cyan
try {
    $rels = Invoke-RestMethod -Uri 'https://gitlab.com/api/v4/projects/librewolf-community%2Fbrowser%2Fbsys6/releases?per_page=5' -TimeoutSec 40
} catch { Fail "GitLab API недоступен: $($_.Exception.Message)" }
$rel = @($rels)[0]
$tag = $rel.tag_name
Write-Host "     последняя версия: $tag"

$zipName = "librewolf-$tag-windows-x86_64-portable.zip"
$candidates = @("https://gitlab.com/librewolf-community/browser/bsys6/-/releases/$tag/downloads/$zipName")
foreach ($l in @($rel.assets.links)) {
    if ("$($l.name)" -like '*windows*x86_64*portable*' -and "$($l.url)" -like '*.zip') { $candidates += "$($l.url)" }
}
$zipPath = Join-Path $Dl $zipName
$okDl = $false
# если файл уже лежит в _download\ (скачан вручную) — используем его
if (Test-Path $zipPath -and (Get-Item $zipPath).Length -gt 20000000) {
    $okDl = $true
    Write-Host "     найден уже скачанный $zipName — использую его"
}
foreach ($u in $candidates) {
    if ($okDl) { break }
    Write-Host "     пробую скачать..."
    & curl.exe -L --fail --retry 2 --connect-timeout 20 --progress-bar -o "$zipPath" "$u"
    if ($LASTEXITCODE -eq 0 -and (Test-Path $zipPath) -and (Get-Item $zipPath).Length -gt 20000000) { $okDl = $true; break }
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
}
if (-not $okDl) {
    Fail ("Не удалось скачать LibreWolf. Открой в браузере страницу релизов, скачай вручную '{0}' и положи в папку _download\ на флешке, потом запусти подготовку снова: https://gitlab.com/librewolf-community/browser/bsys6/-/releases" -f $zipName)
}
Write-Host "     скачано: $([math]::Round((Get-Item $zipPath).Length/1MB,1)) МБ"

# sha256 (если файл суммы доступен — сверим)
$shaUrl = $candidates[0] + '.sha256sum'
$shaPath = $zipPath + '.sha256sum'
& curl.exe -L --fail --retry 1 --connect-timeout 15 -s -o "$shaPath" "$shaUrl"
if ($LASTEXITCODE -eq 0 -and (Test-Path $shaPath)) {
    $expected = ("$(Get-Content $shaPath -Raw)").Trim() -split '\s+' | Select-Object -First 1
    if ($expected -match '^[0-9a-fA-F]{64}$') {
        $actual = (Get-FileHash $zipPath -Algorithm SHA256).Hash.ToLower()
        if ($actual -ne $expected.ToLower()) { Fail "sha256 НЕ СОВПАЛ у LibreWolf (файл повреждён). Удали _download\ и повтори." }
        Write-Host "     sha256 OK" -ForegroundColor Green
    }
}

# распаковка -> app\LibreWolf
Write-Host "     распаковка..."
$stage = Join-Path $Dl 'stage'
New-Item -ItemType Directory -Force -Path $stage | Out-Null
& tar.exe -xf "$zipPath" -C "$stage"
if ($LASTEXITCODE -ne 0) { Fail "tar не смог распаковать zip (нужна Windows 10 1803+)." }
$exe = Get-ChildItem $stage -Recurse -Filter 'LibreWolf.exe' | Select-Object -First 1
if (-not $exe) { Fail "В архиве не нашёлся LibreWolf.exe — распакуй вручную и положи папку браузера в app\LibreWolf\" }
$src = Split-Path $exe.FullName
$dst = Join-Path $App 'LibreWolf'
if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
Move-Item $src $dst
Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
Remove-Item $shaPath -Force -ErrorAction SilentlyContinue
Write-Host "     LibreWolf установлен в app\LibreWolf\" -ForegroundColor Green

# ---------- 2. Xray-core ----------
Write-Host ""
Write-Host "[2/3] Xray-core — узнаю последнюю версию с GitHub..." -ForegroundColor Cyan
try {
    $gh = Invoke-RestMethod -Uri 'https://api.github.com/repos/XTLS/Xray-core/releases/latest' -TimeoutSec 40
} catch { Fail "GitHub API недоступен: $($_.Exception.Message)" }
$asset = @($gh.assets) | Where-Object { $_.name -eq 'Xray-windows-64.zip' } | Select-Object -First 1
if (-not $asset) { Fail "В последнем релизе Xray ($($gh.tag_name)) нет Xray-windows-64.zip. Возьми файл со старой страницы релизов." }
$xz = Join-Path $Dl 'Xray-windows-64.zip'
Download "$($asset.browser_download_url)" $xz
Write-Host "     распаковка в vpn\..."
& tar.exe -xf "$xz" -C "$Vpn"
if ($LASTEXITCODE -ne 0) { Fail "tar не смог распаковать Xray-windows-64.zip." }
$xrayExe = Join-Path $Vpn 'xray.exe'
if (-not (Test-Path $xrayExe)) { Fail "После распаковки нет vpn\xray.exe — распакуй архив вручную в папку vpn\" }
try { $ver = (& $xrayExe version | Select-Object -First 1) } catch { $ver = '(версию показать не удалось)' }
Remove-Item $xz -Force -ErrorAction SilentlyContinue
Write-Host "     Xray готов: $ver" -ForegroundColor Green

# ---------- 3. конфиг VPN ----------
Write-Host ""
Write-Host "[3/3] Конфиг VPN..." -ForegroundColor Cyan
$cfg = Join-Path $Vpn 'config.json'
if (Test-Path $cfg) {
    Write-Host "     vpn\config.json уже есть — пропускаю." -ForegroundColor Green
    Write-Host "     Обновить сервера из подписки: powershell -ExecutionPolicy Bypass -File app\update-sub.ps1" -ForegroundColor DarkGray
} else {
    Write-Host "     Как создать конфиг?" -ForegroundColor Yellow
    Write-Host "       [1] вставить vless:// ссылки вручную (можно несколько — мульти-серверный конфиг)"
    Write-Host "       [2] из подписки (Happ/api.giont.ru) — вставить URL подписки"
    Write-Host "       [3] пропустить (потом запусти подготовку снова)"
    $mode = Read-Host "     Выбор (1/2/3)"
    $conv = $null
    if ("$mode".Trim() -eq '1') { $conv = Join-Path $App 'vless-to-config.ps1' }
    elseif ("$mode".Trim() -eq '2') { $conv = Join-Path $App 'update-sub.ps1' }
    if ($conv) {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$conv"
        if (Test-Path $cfg) { Write-Host "     config.json создан" -ForegroundColor Green }
        else { Write-Host "     [!] Конфиг не создан — см. сообщения выше" -ForegroundColor Red }
    } else {
        Write-Host "     Пропущено. Потом дома (в консоли из папки комплекта):" -ForegroundColor Yellow
        Write-Host "       powershell -ExecutionPolicy Bypass -File app\vless-to-config.ps1   (ссылки вручную)" -ForegroundColor Yellow
        Write-Host "       powershell -ExecutionPolicy Bypass -File app\update-sub.ps1       (из подписки)" -ForegroundColor Yellow
    }
}

Remove-Item $Dl -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "=== ГОТОВО ===" -ForegroundColor Green
Write-Host "Флешку можно брать в колледж: там запускай START.bat, в конце — ЧИСТКА.bat."
Write-Host "Подробности: README-RU.md на флешке."
Write-Host ""
exit 0
