#!/usr/bin/env python3
# update-sub.py — обновление серверов VPN из подписки (api.giont.ru / Happ).
# Исправленная версия: base64 без паддинга/URL-safe, поддержка не только REALITY
# (tls/ws/grpc), валидация узлов, бэкап config.json, обработка ошибок,
# отказ перезаписи при нуле валидных узлов, дедупликация.
#
# Запускать ТОЛЬКО ДОМА:   python app\update-sub.py
# Данные подписки читаются/сохраняются в vpn\sub.txt (url=..., hwid=..., ua=...).

import base64
import json
import os
import sys
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
VPN = os.path.normpath(os.path.join(HERE, "..", "vpn"))
CFG = os.path.join(VPN, "config.json")
SUB = os.path.join(VPN, "sub.txt")

CONFIG_TEMPLATE = """{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "port": 10808,
      "protocol": "socks",
      "settings": { "auth": "noauth", "udp": true },
      "sniffing": { "enabled": true, "destOverride": ["http", "tls"] }
    },
    {
      "tag": "http-in",
      "listen": "127.0.0.1",
      "port": 10809,
      "protocol": "http",
      "settings": {}
    }
  ],
  "outbounds": [
__OUTBOUNDS__
  ],
  "observatory": {
    "subjectSelector": ["proxy-"],
    "probeURL": "https://www.gstatic.com/generate_204",
    "probeInterval": "3m",
    "enableConcurrency": true
  },
  "routing": {
    "domainStrategy": "AsIs",
    "balancers": [
      {
        "tag": "all-proxies",
        "selector": ["proxy-"],
        "strategy": { "type": "leastPing" }
      }
    ],
    "rules": [
      { "type": "field", "network": "tcp,udp", "balancerTag": "all-proxies" }
    ]
  }
}
"""


def load_sub_params():
    """Читает url/hwid/ua из sub.txt; спрашивает недостающее; сохраняет обратно."""
    params = {"url": "", "hwid": "", "ua": "INCY/3.0.28"}
    if os.path.exists(SUB):
        with open(SUB, encoding="utf-8") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    if k.lower() in params and v:
                        params[k.lower()] = v
    if not params["url"]:
        params["url"] = input("URL подписки (https://api.../sub/...): ").strip()
    if not params["hwid"]:
        params["hwid"] = input("x-hwid (GUID клиента; Enter — не отправлять): ").strip()
    if not params["url"].startswith("https://"):
        sys.exit("[X] URL подписки должен начинаться с https://")
    os.makedirs(VPN, exist_ok=True)
    with open(SUB, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("url=%s\r\nhwid=%s\r\nua=%s\r\n" % (params["url"], params["hwid"], params["ua"]))
    return params


def fetch(url, hwid, ua, timeout=25):
    headers = {"User-Agent": ua}
    if hwid:
        headers["x-hwid"] = hwid
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def decode_lines(raw):
    """Тело подписки: либо сразу список vless://, либо base64 (в т.ч. без '=' и url-safe)."""
    raw = raw.strip()
    if "vless://" in raw:
        return raw.splitlines()
    b = "".join(raw.split()).replace("-", "+").replace("_", "/")
    b += "=" * (-len(b) % 4)  # восстановить паддинг
    try:
        text = base64.b64decode(b.encode("ascii"), validate=True).decode("utf-8", "replace")
    except ValueError:  # binascii.Error и UnicodeEncodeError — оба ValueError
        sys.exit("[X] Тело подписки не распознано (не список vless:// и не base64). config.json НЕ тронут.")
    return text.splitlines()


def parse_link(line):
    """vless://... -> dict узла или None (если нерабочий/чужой)."""
    line = line.strip()
    if not line.startswith("vless://"):
        return None
    p = urllib.parse.urlsplit(line)
    if p.scheme != "vless" or not p.hostname or not p.port or not p.username:
        print("[!] не разобрать ссылку, пропускаю:", line[:40] + "...")
        return None
    qs = {k.lower(): v for k, v in urllib.parse.parse_qsl(p.query)}

    node = {
        "uuid": p.username,
        "address": p.hostname,
        "port": p.port,
        "net": qs.get("type", "tcp") or "tcp",
        "sec": qs.get("security", "none") or "none",
        "flow": qs.get("flow", ""),
        "sni": qs.get("sni", ""),
        "fp": qs.get("fp", ""),
        "host": qs.get("host", ""),
        "path": qs.get("path", ""),
        "service_name": qs.get("servicename", ""),
        "alpn": qs.get("alpn", ""),
        "pbk": qs.get("pbk", ""),
        "sid": qs.get("sid", ""),
    }
    if node["sec"] == "reality" and (not node["pbk"] or not node["sni"]):
        print("[!] REALITY без pbk/sni — пропускаю:", node["address"])
        return None
    # flow имеет смысл только с TLS/REALITY
    if node["flow"] and node["sec"] not in ("tls", "reality"):
        node["flow"] = ""
    return node


def build_outbound(node, idx):
    ss = ['      "network": "%s"' % node["net"], '      "security": "%s"' % node["sec"]]
    if node["net"] == "ws":
        blk = '      "wsSettings": {\n        "path": "%s"' % (node["path"] or "/")
        if node["host"]:
            blk += ',\n        "headers": { "Host": "%s" }' % node["host"]
        ss.append(blk + "\n      }")
    elif node["net"] == "grpc":
        ss.append('      "grpcSettings": {\n        "serviceName": "%s"\n      }' % node["service_name"])
    if node["sec"] == "tls":
        sn = node["sni"] or node["host"] or node["address"]
        blk = '      "tlsSettings": {\n        "serverName": "%s",\n        "fingerprint": "%s"' % (
            sn, node["fp"] or "chrome")
        if node["alpn"]:
            blk += ',\n        "alpn": ["%s"]' % node["alpn"].replace(",", '","')
        ss.append(blk + "\n      }")
    elif node["sec"] == "reality":
        blk = ('      "realitySettings": {\n        "show": false,\n'
               '        "fingerprint": "%s",\n        "serverName": "%s",\n        "publicKey": "%s"'
               % (node["fp"] or "firefox", node["sni"], node["pbk"]))
        if node["sid"]:
            blk += ',\n        "shortId": "%s"' % node["sid"]
        ss.append(blk + "\n      }")

    user = '              { "id": "%s", "encryption": "none"' % node["uuid"]
    if node["flow"]:
        user += ', "flow": "%s"' % node["flow"]
    user += " }"

    return (
        '    "tag": "proxy-%d",\n'
        "    \"protocol\": \"vless\",\n"
        "    \"settings\": {\n"
        "      \"vnext\": [\n"
        "        {\n"
        '          "address": "%s",\n'
        "          \"port\": %d,\n"
        "          \"users\": [\n"
        "%s\n"
        "          ]\n"
        "        }\n"
        "      ]\n"
        "    },\n"
        '    "streamSettings": {\n%s\n    }'
    ) % (idx, node["address"], node["port"], user, ",\n".join(ss))


def build_config(nodes):
    parts = ["    {\n" + build_outbound(n, i + 1) + "\n    }" for i, n in enumerate(nodes)]
    parts.append('    { "protocol": "freedom", "tag": "direct" }')
    parts.append('    { "protocol": "blackhole", "tag": "block" }')
    return CONFIG_TEMPLATE.replace("__OUTBOUNDS__", ",\n".join(parts))


def main():
    params = load_sub_params()
    print("[..] Запрашиваю подписку...")
    try:
        raw = fetch(params["url"], params["hwid"], params["ua"])
    except Exception as e:
        sys.exit("[X] Не удалось получить подписку: %s" % e)

    nodes, seen, skipped = [], set(), 0
    for line in decode_lines(raw):
        if line.strip() and not line.strip().startswith("vless://"):
            if "://" in line:
                skipped += 1
            continue
        n = parse_link(line)
        if not n:
            continue
        key = (n["uuid"], n["address"], n["port"])
        if key in seen:
            continue
        seen.add(key)
        nodes.append(n)

    if not nodes:
        sys.exit("[X] Валидных vless:// узлов нет (пропущено чужих: %d). config.json НЕ тронут." % skipped)

    if os.path.exists(CFG):
        with open(CFG + ".bak.json", "w", encoding="utf-8") as f:
            f.write(open(CFG, encoding="utf-8").read())
        print("[i] Старый конфиг — в config.bak.json")

    with open(CFG, "w", encoding="utf-8", newline="\n") as f:
        f.write(build_config(nodes))

    print("[+] Готово: %d сервер(ов) записано в config.json" % len(nodes))
    for i, n in enumerate(nodes, 1):
        print("    proxy-%d: %s:%s  sni=%s  [%s/%s]" % (i, n["address"], n["port"], n["sni"], n["net"], n["sec"]))
    if skipped:
        print("[i] Пропущено чужих (не vless) строк: %d" % skipped)


if __name__ == "__main__":
    main()
