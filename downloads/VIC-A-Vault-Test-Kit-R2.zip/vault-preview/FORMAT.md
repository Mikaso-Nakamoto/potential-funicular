# VIC-A vault preview: format 02 (not a released migration)

## Envelope

`VICAVA02` (8 ASCII bytes) | salt (16 bytes) | nonce (12 bytes) |
AES-256-GCM ciphertext (N bytes) | authentication tag (16 bytes).
The first 36 bytes are authenticated associated data. Plaintext limit: 8 MiB.
Every encryption generates a fresh salt and nonce using libsodium randombytes_buf.
Unknown magic, including preview `VICAVA01`, is rejected without fallback.
No implicit conversion of existing vaults. A future format change needs a new magic
and explicit, tested migration. JSON payload version is separate from crypto version.

## Password and KDF

Input: at most 1024 UTF-16 code units before normalization. Encode NFC-normalized
text as strict UTF-8, with no trimming, case folding or compatibility normalization.
Normalization is identical for creation, confirmation and opening. It does not
correct keyboard layouts or visually similar characters. The temporary normalized
managed string cannot be reliably erased; this is an explicit limitation.

Key: libsodium crypto_pwhash algorithm 2 (Argon2id13), output 32 bytes,
opslimit 3, memlimit 67108864 bytes. This uses libsodium's p=1 mapping; it is NOT
claimed to implement RFC 9106's p=4 recommended profile. Parameters are fixed in
code, never accepted from an unauthenticated file. Changing them requires new magic.

Creation policy: at least 16 UTF-16 code units after NFC, reject a small explicit
set of common patterns, fewer than 8 distinct non-whitespace lowercased characters,
and periodic repetition. This is a rejection heuristic, NOT an entropy estimator
or zxcvbn equivalent. Passing it does NOT imply resistance to offline guessing.
Recommendation: six independently randomly selected words from a trusted password
manager, with an adequately large word list. Password loss is unrecoverable.
Opening does not apply creation heuristics to preserve access if policy evolves.

## Payload and publication

JSON version 1: subscription.url (HTTPS, no userinfo/fragment), subscription.hwid,
activeConfig, optional createdAtUtc. No node list/selection state yet.
Read and write require Assert-VaultDocument, including Assert-ConfigObjectPolicy.
That object policy is the existing tunnel policy factored out of its file wrapper;
no decrypted configuration file is needed for validation.

Read opens one FileStream with FileShare.Read, checks length on that handle,
reads exactly the bounded length and rejects extra/truncated bytes. This narrows
TOCTOU exposure; it is not protection against privileged processes/filesystems.
New vault creation only: CreateNew staging file beside target, write encrypted
bytes, Flush(true), close, authenticate and validate read-back, File.Move without
replacement. Cleanup only removes a staging file this operation created.
No guarantee against all power failures, malicious filesystem changes or rollback.
No update/backup recovery protocol yet. Originals are never automatically deleted.

## Dependency and trust

P/Invoke uses an absolute main DLL path and DefaultDllImportSearchPaths with
UseDllDirectoryForDependencies | System32 (requires supported .NET/Windows). No process-global DLL
search mutation. CheckSupport also requires runtime version string 1.0.22. Source SHA-256 is pinned in Vault.Common.ps1; archive SHA-256 is
pinned; installed DLL hash is recorded in a local manifest. These checks do NOT
protect against an attacker able to edit the verifier or manifest.
R2 installs from the pinned official MSVC ZIP (SHA-256
3e03a726fac4bc09cb61d8f29d658ef7a5eca0811de59082130414f7ca2e4279), selecting
one x64/Release/v143/dynamic/libsodium.dll. It copies only that bounded regular ZIP
member into a fixed staging filename, never archive-controlled output paths.
The original MinGW package was rejected for libgcc_s_seh-1.dll and is not allowed.
MSVC ReleaseDLL uses the DLL CRT: R2 requires needed vcruntime140[_1].dll in
System32 with a valid Microsoft Authenticode signature and checks their imports too.
No runtime redistribution or installation, no PATH lookup. UCRT API contracts and
core Windows modules remain platform trust. This is a documented prerequisite,
not a claim of zero external runtime dependencies. Actual Windows R2 execution
and official MSVC binary import inspection have not been possible here.

The isolated test kit adds a non-executing PE32+ direct-import gate with a narrow
Windows/verified-Microsoft-runtime allowlist; unexpected dependencies or delay imports stop installation.
It is not a full recursive or dynamic import audit. Synthetic inspector and vault
I/O/negative test scripts exist but have not been executed here on Windows.

Outstanding release gates: actual official Windows DLL import/dependency review;
Windows adversarial ZIP-entry tests; C# compilation and loader tests in Windows
PowerShell 5.1; file-I/O, policy and failure-path execution tests; full migration,
mandatory unlock, stdin Xray integration and encrypted subscription refresh.
Do not interpret Linux format tests as proof these Windows paths work.
