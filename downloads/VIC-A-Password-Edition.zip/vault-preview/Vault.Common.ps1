$vaultToolDirectory = $PSScriptRoot
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Assert-VaultSupportIntegrity {
    foreach ($entry in @(
        @('Test-SodiumImports.ps1','78f20314b2dbcfbab33fa486a7f36201ad6abd76edbc373ebd480f2a25277e1f'),
        @('SodiumPe.cs','79c7dd318eb2dda05d8d6e316c1848821c6d511a05ab1c18dbcf9edf9381f4df')
    )) {
        if ((Get-FileHash -LiteralPath (Join-Path $vaultToolDirectory $entry[0]) -Algorithm SHA256).Hash -ne $entry[1]) {
            throw 'Vault support integrity check failed.'
        }
    }
}
function Read-BoundedVaultBytes([string]$Path) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        $length = $stream.Length
        if ($length -lt 52 -or $length -gt 8388660) { throw 'Vault size outside allowed range.' }
        $bytes = New-Object byte[] ([int]$length)
        $offset = 0
        while ($offset -lt $bytes.Length) {
            $count = $stream.Read($bytes, $offset, $bytes.Length - $offset)
            if ($count -eq 0) { throw 'Truncated vault.' }
            $offset += $count
        }
        if ($stream.ReadByte() -ne -1) { throw 'Vault changed during read.' }
        return ,$bytes
    } finally { $stream.Dispose() }
}
function Assert-VaultDocument($Document) {
    Assert-Fields $Document @('version','createdAtUtc','subscription','activeConfig') @('version','subscription','activeConfig')
    if ($Document.version -ne 1) { throw 'Unsupported payload version.' }
    Assert-Fields $Document.subscription @('url','hwid') @('url','hwid')
    $uri = $null
    if (-not [Uri]::TryCreate([string]$Document.subscription.url, [UriKind]::Absolute, [ref]$uri) -or
        $uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Fragment) { throw 'Invalid subscription URL.' }
    $null = Convert-DeviceHwid $Document.subscription.hwid
    Assert-ConfigObjectPolicy $Document.activeConfig
}
