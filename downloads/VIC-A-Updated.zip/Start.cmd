@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0vica\Start-Vica.ps1"
set "code=%errorlevel%"
if not "%code%"=="0" (
  echo VIC-A stopped. Keep this error visible; do not share secrets.
  pause
)
exit /b %code%
