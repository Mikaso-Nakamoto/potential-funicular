@echo off
setlocal
title VIC-A - Launcher Repair
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Start-RepairConsole.ps1"
if errorlevel 1 (
  echo Launcher stopped. Read the error above. No policy bypass.
  pause
)
endlocal
