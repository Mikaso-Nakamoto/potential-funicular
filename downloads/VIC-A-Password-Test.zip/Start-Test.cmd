@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Start-PasswordTest.ps1"
set "code=%errorlevel%"
echo Password TEST ended. No production import or cleanup.
pause
exit /b %code%
