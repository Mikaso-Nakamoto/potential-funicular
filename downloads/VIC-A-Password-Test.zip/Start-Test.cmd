@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Start-PasswordTest.ps1"
set "code=%errorlevel%"
if not "%code%"=="0" (
  echo Password TEST stopped. No production import or cleanup.
  pause
)
exit /b %code%
